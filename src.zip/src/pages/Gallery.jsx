// src/components/Gallery.jsx
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import {
  X,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ExternalLink,
} from "lucide-react";

const Gallery = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, threshold: 0.1 });
  const [selectedImage, setSelectedImage] = useState(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const projects = [
    {
      title: "2 MW Solar Power Plant - Akola",
      image: "/api/placeholder/600/400",
      description: "Large-scale ground-mounted solar power plant",
      category: "Utility Scale",
      year: "2023",
    },
    {
      title: "1 MW Solar Power Plant - Kopargaon",
      image: "/api/placeholder/600/400",
      description: "Commercial solar power installation",
      category: "Commercial",
      year: "2022",
    },
    {
      title: "Solar Tree - Nashik",
      image: "/api/placeholder/600/400",
      description: "First ever SOLAR TREE with Net-metering in Maharashtra",
      category: "Innovation",
      year: "2023",
    },
    {
      title: "100 KW Industrial Rooftop - Nashik",
      image: "/api/placeholder/600/400",
      description: "Industrial rooftop solar project",
      category: "Industrial",
      year: "2022",
    },
    {
      title: "Pre-engineered Structure - Nashik",
      image: "/api/placeholder/600/400",
      description: "10,000 sq.ft. industrial shed structure",
      category: "Construction",
      year: "2021",
    },
    {
      title: "Canal-top Solar Project - Gujarat",
      image: "/api/placeholder/600/400",
      description: "Feasibility study for innovative canal-top installation",
      category: "Research",
      year: "2023",
    },
  ];

  const openLightbox = (image, index) => {
    setSelectedImage(image);
    setCurrentIndex(index);
  };

  const closeLightbox = () => {
    setSelectedImage(null);
  };

  const goToPrevious = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? projects.length - 1 : prevIndex - 1
    );
  };

  const goToNext = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === projects.length - 1 ? 0 : prevIndex + 1
    );
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50, scale: 0.9 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut",
      },
    },
  };

  const imageHoverVariants = {
    hover: {
      scale: 1.1,
      transition: {
        duration: 0.4,
        ease: "easeOut",
      },
    },
  };

  return (
    <section
      id="gallery"
      className="section-padding bg-gradient-to-br from-gray-50 to-blue-50 relative overflow-hidden z-0 pt-38"
    >
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-0 w-72 h-72 bg-primary/5 rounded-full -translate-x-1/2 -translate-y-1/2"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-green-500/5 rounded-full translate-x-1/3 translate-y-1/3"></div>

      <div className="container-custom px-6 lg:px-8 xl:px-12 relative">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={isInView ? { scale: 1 } : { scale: 0 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="inline-block mb-4"
          ></motion.div>
          {/* <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Project{" "}
            <span className="text-gradient bg-gradient-to-r from-primary to-green-600">
              Gallery
            </span>
          </h2> */}
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Project{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-700 to-gray-900">
              Gallery
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Explore our innovative solar energy projects that are powering a
            sustainable future with cutting-edge technology and exceptional
            craftsmanship.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-2 xl:grid-cols-3 gap-8 lg:gap-10"
        >
          {projects.map((project, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ y: -8, scale: 1.02 }}
              className="group bg-white rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition-all duration-500 cursor-pointer border border-gray-100"
              onClick={() => openLightbox(project.image, index)}
            >
              <div className="relative h-64 bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden">
                <motion.img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover"
                  variants={imageHoverVariants}
                  whileHover="hover"
                />

                {/* Overlay with gradient and info */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex flex-col justify-end p-6">
                  <div className="transform translate-y-8 group-hover:translate-y-0 transition-transform duration-500">
                    <div className="flex gap-2 mb-3">
                      <span className="bg-primary text-white px-3 py-1 rounded-full text-xs font-medium">
                        {project.category}
                      </span>
                      <span className="bg-white/20 text-white px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm">
                        {project.year}
                      </span>
                    </div>
                    <p className="text-white text-sm leading-relaxed">
                      {project.description}
                    </p>
                  </div>
                </div>

                {/* Hover action indicator */}
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full p-2 opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                  <ZoomIn size={20} className="text-gray-700" />
                </div>
              </div>

              <div className="p-6">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-bold text-gray-900 text-lg leading-tight group-hover:text-primary transition-colors duration-300 pr-4">
                    {project.title}
                  </h3>
                  <ExternalLink
                    size={18}
                    className="text-gray-400 group-hover:text-primary mt-1 flex-shrink-0 transition-colors duration-300"
                  />
                </div>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {project.description}
                </p>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Enhanced Lightbox */}
        <AnimatePresence>
          {selectedImage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/95 backdrop-blur-sm z-50 flex items-center justify-center p-4 lg:p-8"
              onClick={closeLightbox}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0, y: 50 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 50 }}
                transition={{ type: "spring", damping: 25 }}
                className="relative w-full max-w-6xl max-h-full"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button
                  onClick={closeLightbox}
                  className="absolute -top-4 -right-4 lg:-top-8 lg:-right-8 bg-white hover:bg-gray-100 text-gray-900 rounded-full p-3 shadow-2xl hover:scale-110 transition-all duration-300 z-10"
                >
                  <X size={24} />
                </button>

                <div className="relative bg-white rounded-3xl overflow-hidden shadow-2xl">
                  {/* Main Image Container */}
                  <div className="relative bg-gray-900">
                    <motion.img
                      key={currentIndex}
                      initial={{ opacity: 0, scale: 1.1 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ duration: 0.4 }}
                      src={projects[currentIndex].image}
                      alt={projects[currentIndex].title}
                      className="w-full h-auto max-h-[70vh] object-contain"
                    />

                    {/* Navigation Arrows */}
                    <button
                      onClick={goToPrevious}
                      className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-gray-900 rounded-full p-3 shadow-2xl hover:scale-110 transition-all duration-300 backdrop-blur-sm"
                    >
                      <ChevronLeft size={28} />
                    </button>

                    <button
                      onClick={goToNext}
                      className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-gray-900 rounded-full p-3 shadow-2xl hover:scale-110 transition-all duration-300 backdrop-blur-sm"
                    >
                      <ChevronRight size={28} />
                    </button>
                  </div>

                  {/* Info Panel */}
                  <div className="p-6 lg:p-8 bg-gradient-to-r from-gray-50 to-white">
                    <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex flex-wrap gap-2 mb-3">
                          <span className="bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">
                            {projects[currentIndex].category}
                          </span>
                          <span className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm font-semibold">
                            {projects[currentIndex].year}
                          </span>
                        </div>
                        <h3 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-3">
                          {projects[currentIndex].title}
                        </h3>
                        <p className="text-gray-600 text-lg leading-relaxed">
                          {projects[currentIndex].description}
                        </p>
                      </div>

                      <div className="flex items-center gap-4 lg:flex-col lg:items-end">
                        <div className="text-sm font-semibold text-gray-500 bg-gray-100 px-4 py-2 rounded-full">
                          {currentIndex + 1} / {projects.length}
                        </div>
                        <button className="bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-full font-semibold transition-all duration-300 hover:scale-105 shadow-lg hover:shadow-xl">
                          View Project Details
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* View More Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="text-center mt-16"
        ></motion.div>
      </div>
    </section>
  );
};

export default Gallery;
